import React from "react";


function Potato(){
    return <h3>I like potato</h3>
}
export default Potato;